# Reproduce the trading.hyena17 timing report

`./run.sh` regenerates all six plots and summary tables from the included snapshot. It does not contact Airflow or need credentials. The first chart contains all 252 selected startup tasks, including parameter generation, transfers, and checks.

## Install and run

Use Python 3.11. The original environment used Python 3.11.4 with these package versions:

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install pandas==1.5.2 numpy==1.26.4 matplotlib==3.10.6
PYTHON=.venv/bin/python bash run.sh
```

Run from the directory containing `run.sh`, `analyze.py`, `attempts.csv`, and `metadata.json`. The script also works when invoked by its absolute path. If the dependencies are already installed, `bash run.sh` is sufficient.

The historical snapshot covers 20 scheduled dates from 2026-10-16 through 2026-11-12. Times are converted from UTC to Asia/Shanghai, UTC+8. No tasks are rerun. The included task and account names are the original Airflow identifiers.

## Files and outputs

- `analyze.py`: the complete plotting and summary script, including deadline-overlap and coverage checks.
- `export_airflow.py`: read-only metadata export and reconstruction of earlier task attempts from audit events.
- `attempts.csv`, `metadata.json`, and `runs.csv`: the recorded timing snapshot.
- Six PNG figures, including `morning-timeline.png`, the full 252-row startup timeline.
- `daily-readiness.csv`, `family-summary.csv`, `latest-morning-tasks.csv`, and `summary.json`: generated tables and headline values.
- `request-phases.csv`, `readiness-phases.csv`, and `log-evidence.txt`: original Nov 12 log evidence. These files are separate from the plotting inputs.

## Refresh from Airflow

The default connection is the SSH user `infra` on `infra.t1`. The remote user needs permission to read the existing `airflow` container through Docker. The exporter uses that container's configured metadata connection; it never prints the connection URL or its credentials.

Copy the bundle to a separate directory before refreshing if you want to retain the original results. After a completed trading session, use SSH key authentication:

```bash
export AIRFLOW_SSH_USER=infra
export AIRFLOW_SSH_HOST=infra.t1
PYTHON=.venv/bin/python bash run.sh --refresh
```

If password authentication is required, set `AIRFLOW_SSH_PASSWORD` through your environment or secret manager. In an interactive Bash shell, enter it without showing or storing it in shell history:

```bash
read -r -s -p 'SSH password: ' AIRFLOW_SSH_PASSWORD
printf '\n'
export AIRFLOW_SSH_PASSWORD
PYTHON=.venv/bin/python bash run.sh --refresh
unset AIRFLOW_SSH_PASSWORD
```

This mode needs `sshpass`. It passes the password through the environment rather than a command-line argument. The runner disables shell tracing before handling credentials. No password values or database credentials belong in these files.

Refresh selects the latest 20 completed scheduled runs for `trading.hyena17`, reads task instances, failure records, and audit events, and writes `attempts.csv`, `metadata.json`, and `runs.csv` locally. The MySQL session is read-only. It does not clear tasks, trigger DAGs, restart services, or change the remote database.

The plotting script then regenerates the figures and summary tables. Fresh results can differ from the Nov 12 report. The article text and the three original log-evidence files are not refreshed automatically. An incomplete or changed task layout can fail the account/colo coverage checks instead of silently producing a partial chart.

## Interpretation limits

Only successful first morning attempts enter duration percentiles. Failed and unresolved attempts remain in the snapshot. Missing data is not treated as a zero-duration success. Queue measurements require a surviving matching task-instance record. Long-lived trading sessions are measured by their start times rather than treated as slow setup tasks.
